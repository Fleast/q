const groupmenu = (prefix) => { 
	return `
╭───「 *GROUP MENU* 」───
│
├➲ *${prefix}modeanime [On/Off]*
├➲ *${prefix}naruto*
├➲ *${prefix}minato*
├➲ *${prefix}boruto*
├➲ *${prefix}hinata*
├➲ *${prefix}sakura*
├➲ *${prefix}sasuke*
├➲ *${prefix}kaneki*
├➲ *${prefix}toukachan*
├➲ *${prefix}rize*
├➲ *${prefix}akira*
├➲ *${prefix}itori*
├➲ *${prefix}kurumi*
├➲ *${prefix}miku*
├➲ *${prefix}anime*
├➲ *${prefix}animecry*
├➲ *${prefix}neonime*
├➲ *${prefix}animekiss*
├➲ *${prefix}wink*
├➲ *${prefix}welcome [On/Off]*
├➲ *${prefix}grup [buka/tutup]*
├➲ *${prefix}antilink [on/off*
├➲ *${prefix}ownergrup*
├➲ *${prefix}setpp*
├➲ *${prefix}infogc*
├➲ *${prefix}add*
├➲ *${prefix}kick*
├➲ *${prefix}promote*
├➲ *${prefix}demote*
├➲ *${prefix}setname*
├➲ *${prefix}setdesc*
├➲ *${prefix}linkgrup*
├➲ *${prefix}tagme*
├➲ *${prefix}hidetag*
├➲ *${prefix}tagall*
├➲ *${prefix}mentionall*
├➲ *${prefix}fitnah*
├➲ *${prefix}listadmin*
├➲ *${prefix}openanime*
├➲ *${prefix}edotense*
├➲ *${prefix}nsfw [On/Off]*
├➲ *${prefix}nsfwloli*
├➲ *${prefix}nsfwblowjob*
├➲ *${prefix}nsfwneko*
├➲ *${prefix}nsfwtrap*
├➲ *${prefix}hentai*
├➲ *${prefix}simih [On/Off]*
│
╰────────────────────
	
           *©Hanbei BOT*`
	}
exports.groupmenu = groupmenu